package testJava_1;

public class Portfolio_8 {
	public static void main(String[] args) {
		int max = 0;
		int[i] array = Math.random(i = 0; i <=100; i++);
		
		for (int i = 0; i < array.lenth; i++) {
			if(max < array[i]) {
				max = array[i]
			}
		}
		System.out.println("max : " + max);
		
	}
}
