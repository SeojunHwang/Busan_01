import Vue from 'vue' //  ES6 방식의 자바스크립트 모듈 로드 방식
import App from './App.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
