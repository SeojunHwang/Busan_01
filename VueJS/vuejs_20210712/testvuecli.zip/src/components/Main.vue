<template>
    <div>
        <br><hr><br><br>
        <h1>메인 컨텐츠</h1>
        <br><br><hr><br>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>

</style>